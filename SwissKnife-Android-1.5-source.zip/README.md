# SwissKey Android

Android application and LSPosed module for applying the ten PNG digit artworks from an iOS `.passthm` archive to the native PIN keypad in OPlus SystemUI. Includes the supplied MaterialYou theme. The module changes drawings only; the native keypad still handles PIN entry, touch feedback, and accessibility.

## Install

1. Install version 1.5 over version 1.4. The debug signing certificate is the same. If Android rejects the update because version 1.0 has a different certificate, uninstall that version first and reimport any custom theme.
2. Enable SwissKey Android in LSPosed and select `com.android.systemui` as its scope.
3. Launch SwissKey Android. The supplied MaterialYou theme is installed on first launch. To use another theme, select **Импортировать .passthm**.
4. Select **Применить тему**, grant root to restart SystemUI, then open the PIN keypad. Return to the app. It refreshes the result on resume; **Скопировать диагностику** includes SystemUI component names and errors. The LSPosed log records `[SwissKey] Styled ...` when the keypad is styled.
5. To revert, select **Выключить тему**. If root restart fails, reboot the device.

Version 1.3 redraws the Android application as a grouped iOS-style Passcode screen with a large heading, a lock-screen preview, grouped theme/action/status sections, and the heart app icon extracted from the supplied Swiss Knife IPA. This is a native Android interpretation of that screen, retaining the functional import, apply, disable, and diagnostic actions.

Version 1.4 accepts English and other language digit filenames (`en-0-…png` through `en-9-…png`) and simple `0.png`/`digit_0.png` ZIP layouts, selects ten valid PNGs before replacing the active theme, and shows file access, archive, or missing digit errors in the app. The supplied `MaterialYou.passthm` uses the English filename form.

Version 1.5 sets the launcher label to **Swiss Knife** and uses the app's original faceted-heart artwork from the supplied IPA as density-specific launcher icons. The in-app header uses the same higher-resolution image.

If the keypad still has its original appearance, return to the app and tap **Скопировать диагностику**. The copied text distinguishes a missing LSPosed hook, an unavailable theme provider, and an OEM keypad whose digit buttons are not ordinary text views. When buttons are not found, the diagnostic includes class names and dimensions of the PIN view hierarchy, without reading entered PIN values. The app refreshes this information when it returns from the lock screen. This release has been compiled and its APK signature verified; its appearance on the target ColorOS 17 device remains to be checked.

The hook recognizes `COUINumericKeyboard`, the AOSP `NumPadKey` fallback, and the observed `com.oplus.keyguard.security.view.OplusKeyguardFixedPinView` container. Inside the latter, it decorates the existing numbered views without changing input handling. ROMs that draw the keypad in a canvas or another component may need a further adapter. No entered PIN values are stored or read by this module.

## Build

Use JDK 21, Gradle 9.4.1, Android SDK Platform 36 and Build Tools 36.0.0:

```sh
./gradlew :app:assembleDebug
```

The source theme is `app/src/main/assets/default_theme/0.png` through `9.png`. Additional `.passthm` files are validated and copied to the app's private storage; SystemUI reads the ten images through a read-only ContentProvider. Import size and image dimensions are bounded. The APK uses an Android debug signing key for this build.
