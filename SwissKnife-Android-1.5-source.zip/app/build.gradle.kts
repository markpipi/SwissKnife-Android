plugins {
    id("com.android.application")
}
android {
    namespace = "dev.biom.swisskey"
    compileSdk = 36
    defaultConfig {
        applicationId = "dev.biom.swisskey"
        minSdk = 29
        targetSdk = 36
        versionCode = 6
        versionName = "1.5"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
dependencies {
    compileOnly("de.robv.android.xposed:api:82")
}
