package dev.biom.swisskey;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;

public final class MainActivity extends Activity {
    private static final int PICK_THEME = 101;
    private static final int BACKGROUND = 0xfff2f2f7;
    private static final int INK = 0xff16171b;
    private static final int SECONDARY = 0xff747783;
    private static final int BLUE = 0xff1572ed;
    private static final int GREEN = 0xff259b62;
    private LinearLayout root;
    private TextView stateLabel;
    private TextView themeLabel;
    private TextView detailLabel;
    private String transientMessage;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BACKGROUND);
        getWindow().setNavigationBarColor(BACKGROUND);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR |
                View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        try { ThemeStore.ensureDefault(this); }
        catch (IOException error) { transientMessage = "Тема недоступна: " + error.getMessage(); }
        render();
    }

    private SharedPreferences prefs() {
        return ThemeStore.storage(this).getSharedPreferences("theme", 0);
    }

    private void render() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BACKGROUND);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(22), dp(20), dp(34));
        scroll.addView(root);
        setContentView(scroll);

        LinearLayout branding = new LinearLayout(this);
        branding.setGravity(Gravity.CENTER_VERTICAL);
        ImageView icon = new ImageView(this);
        icon.setImageResource(R.drawable.swissknife_mark);
        icon.setScaleType(ImageView.ScaleType.FIT_CENTER);
        branding.addView(icon, new LinearLayout.LayoutParams(dp(36), dp(36)));
        TextView brand = label("Swiss Knife", 16, INK, true);
        LinearLayout.LayoutParams brandLayout = new LinearLayout.LayoutParams(-2, -2);
        brandLayout.leftMargin = dp(10);
        branding.addView(brand, brandLayout);
        root.addView(branding);

        TextView title = label("Passcode", 36, INK, true);
        LinearLayout.LayoutParams titleLayout = new LinearLayout.LayoutParams(-1, -2);
        titleLayout.topMargin = dp(20);
        root.addView(title, titleLayout);
        TextView subtitle = label("Темы клавиатуры блокировки", 15, SECONDARY, false);
        root.addView(subtitle);

        sectionTitle("ПРЕДПРОСМОТР");
        LinearLayout preview = new LinearLayout(this);
        preview.setOrientation(LinearLayout.VERTICAL);
        preview.setGravity(Gravity.CENTER_HORIZONTAL);
        preview.setPadding(dp(18), dp(22), dp(18), dp(18));
        preview.setBackground(round(0xff242833, 24));
        root.addView(preview, new LinearLayout.LayoutParams(-1, -2));
        TextView prompt = label("Введите пароль", 18, Color.WHITE, false);
        prompt.setGravity(Gravity.CENTER);
        preview.addView(prompt);
        LinearLayout dots = new LinearLayout(this);
        dots.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams dotsLayout = new LinearLayout.LayoutParams(-1, dp(38));
        dotsLayout.topMargin = dp(5);
        preview.addView(dots, dotsLayout);
        for (int i = 0; i < 6; i++) {
            View dot = new View(this);
            GradientDrawable outline = round(0x00000000, 100);
            outline.setStroke(dp(1), 0xffc9cbd3);
            dot.setBackground(outline);
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(dp(11), dp(11));
            p.leftMargin = dp(8); p.rightMargin = dp(8);
            dots.addView(dot, p);
        }
        int[] digits = {1,2,3,4,5,6,7,8,9,-1,0,-1};
        for (int row = 0; row < 4; row++) {
            LinearLayout line = new LinearLayout(this);
            line.setGravity(Gravity.CENTER);
            preview.addView(line, new LinearLayout.LayoutParams(-1, dp(63)));
            for (int col = 0; col < 3; col++) {
                int digit = digits[row * 3 + col];
                ImageView image = new ImageView(this);
                image.setScaleType(ImageView.ScaleType.FIT_CENTER);
                if (digit >= 0) image.setImageBitmap(BitmapFactory.decodeFile(
                        ThemeStore.image(this, digit).getAbsolutePath()));
                LinearLayout.LayoutParams item = new LinearLayout.LayoutParams(0, dp(60), 1);
                line.addView(image, item);
            }
        }
        TextView previewNote = label("Предпросмотр темы · ввод PIN остаётся системным", 12, 0xffa7aebd, false);
        previewNote.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams noteLayout = new LinearLayout.LayoutParams(-1, -2);
        noteLayout.topMargin = dp(10);
        preview.addView(previewNote, noteLayout);

        sectionTitle("ТЕМА");
        LinearLayout themeCard = card();
        LinearLayout row = horizontalRow(themeCard, "Выбранная тема", "✦", false);
        themeLabel = label("", 14, SECONDARY, false);
        themeLabel.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        row.addView(themeLabel, new LinearLayout.LayoutParams(0, dp(54), 1));
        row.addView(chevron(), new LinearLayout.LayoutParams(dp(18), dp(54)));
        row.setOnClickListener(v -> importTheme());
        separator(themeCard);
        LinearLayout importRow = horizontalRow(themeCard, "Импортировать .passthm", "↓", true);
        importRow.setOnClickListener(v -> importTheme());
        caption("Файл темы с изображениями цифр 0–9.");

        sectionTitle("ДЕЙСТВИЯ");
        LinearLayout actions = card();
        LinearLayout applyRow = horizontalRow(actions, "Применить тему", "✓", true);
        applyRow.setOnClickListener(v -> {
            ThemeStore.setEnabled(this, true);
            refresh();
            restartSystemUi();
        });
        separator(actions);
        LinearLayout resetRow = horizontalRow(actions, "Выключить тему", "↺", true);
        resetRow.setOnClickListener(v -> {
            ThemeStore.setEnabled(this, false);
            refresh();
            restartSystemUi();
        });
        caption("После изменения SystemUI перезапустится. Разблокировка продолжит работать как обычно.");

        sectionTitle("СОСТОЯНИЕ");
        LinearLayout statusCard = card();
        stateLabel = label("", 16, INK, true);
        stateLabel.setPadding(dp(16), dp(15), dp(16), dp(4));
        statusCard.addView(stateLabel);
        detailLabel = label("", 13, SECONDARY, false);
        detailLabel.setPadding(dp(16), 0, dp(16), dp(15));
        statusCard.addView(detailLabel);
        separator(statusCard);
        LinearLayout diagnosticRow = horizontalRow(statusCard, "Скопировать диагностику", "⧉", true);
        diagnosticRow.setOnClickListener(v -> copyDiagnostics());
        refresh();
    }

    private void refresh() {
        if (stateLabel == null) return;
        boolean enabled = ThemeStore.enabled(this);
        stateLabel.setText(enabled ? "●  Тема включена" : "○  Тема выключена");
        stateLabel.setTextColor(enabled ? GREEN : INK);
        String last = prefs().getString("last_keypad", "");
        String error = prefs().getString("last_error", "");
        String hint = !error.isEmpty() ? "Ошибка: " + error :
                last.isEmpty() ? "Открой экран PIN, чтобы проверить применение." :
                        "Оформлено: " + last;
        if (transientMessage != null) hint = transientMessage + "\n" + hint;
        detailLabel.setText(hint);
        if (themeLabel != null) themeLabel.setText(prefs().getString("theme_name", "MaterialYou"));
    }

    private void importTheme() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        startActivityForResult(intent, PICK_THEME);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != PICK_THEME || resultCode != RESULT_OK || data == null || data.getData() == null) return;
        try {
            ThemeStore.importTheme(this, data.getData());
            String name = "Импортированная тема";
            try (Cursor cursor = getContentResolver().query(data.getData(),
                    new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
                if (cursor != null && cursor.moveToFirst()) name = cursor.getString(0);
            } catch (RuntimeException ignored) { }
            if (name != null && name.toLowerCase(java.util.Locale.ROOT).endsWith(".passthm"))
                name = name.substring(0, name.length() - 8);
            prefs().edit().putString("theme_name", name == null ? "Импортированная тема" : name).apply();
            transientMessage = "Тема загружена. Нажми «Применить тему».";
            render();
            Toast.makeText(this, transientMessage, Toast.LENGTH_LONG).show();
        } catch (IOException error) {
            transientMessage = "Ошибка импорта: " + error.getMessage();
            refresh();
            Toast.makeText(this, transientMessage, Toast.LENGTH_LONG).show();
        } catch (RuntimeException error) {
            transientMessage = "Ошибка импорта: " + error.getClass().getSimpleName() +
                    (error.getMessage() == null ? "" : " — " + error.getMessage());
            refresh();
            Toast.makeText(this, transientMessage, Toast.LENGTH_LONG).show();
        }
    }

    private void copyDiagnostics() {
        String report = "Клавиатура: " + prefs().getString("last_keypad", "") +
                "\nОшибка: " + prefs().getString("last_error", "") +
                "\nОбнаруженные компоненты:" + prefs().getString("candidates", "") +
                "\nРазметка PIN:" + prefs().getString("structure", "");
        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        clipboard.setPrimaryClip(ClipData.newPlainText("SwissKey диагностика", report));
        transientMessage = "Диагностика скопирована.";
        refresh();
    }

    private void restartSystemUi() {
        transientMessage = "Перезапускаю SystemUI…";
        refresh();
        new Thread(() -> {
            String message;
            try {
                Process process = new ProcessBuilder("su", "-c", "killall com.android.systemui").start();
                int code = process.waitFor();
                message = code == 0 ? "SystemUI перезапущен. Проверь экран PIN." :
                        "Root вернул код " + code + ". Перезагрузи телефон вручную.";
            } catch (Exception error) {
                message = "Не удалось перезапустить SystemUI. Перезагрузи телефон вручную.";
            }
            String resultMessage = message;
            runOnUiThread(() -> { transientMessage = resultMessage; refresh(); });
        }, "systemui-restart").start();
    }

    @Override protected void onResume() {
        super.onResume();
        refresh();
    }

    private void sectionTitle(String value) {
        TextView heading = label(value, 12, SECONDARY, false);
        heading.setLetterSpacing(0.08f);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.topMargin = dp(25); p.bottomMargin = dp(8); p.leftMargin = dp(14);
        root.addView(heading, p);
    }

    private LinearLayout card() {
        LinearLayout group = new LinearLayout(this);
        group.setOrientation(LinearLayout.VERTICAL);
        group.setBackground(round(Color.WHITE, 17));
        root.addView(group, new LinearLayout.LayoutParams(-1, -2));
        return group;
    }

    private LinearLayout horizontalRow(LinearLayout parent, String name, String symbol, boolean endChevron) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(16), 0, dp(12), 0);
        parent.addView(row, new LinearLayout.LayoutParams(-1, dp(56)));
        TextView glyph = label(symbol, 20, BLUE, false);
        glyph.setGravity(Gravity.CENTER);
        row.addView(glyph, new LinearLayout.LayoutParams(dp(30), -1));
        TextView text = label(name, 16, INK, false);
        LinearLayout.LayoutParams textP = new LinearLayout.LayoutParams(endChevron ? 0 : -2, -2,
                endChevron ? 1 : 0);
        textP.leftMargin = dp(8);
        row.addView(text, textP);
        if (endChevron) row.addView(chevron(), new LinearLayout.LayoutParams(dp(18), -1));
        return row;
    }

    private TextView chevron() {
        TextView arrow = label("›", 28, 0xffc8c8cf, false);
        arrow.setGravity(Gravity.CENTER);
        return arrow;
    }

    private void separator(LinearLayout parent) {
        View divider = new View(this);
        divider.setBackgroundColor(0xffe8e8ed);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(1));
        p.leftMargin = dp(54);
        parent.addView(divider, p);
    }

    private void caption(String value) {
        TextView caption = label(value, 13, SECONDARY, false);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.leftMargin = dp(14); p.rightMargin = dp(10); p.topMargin = dp(8);
        root.addView(caption, p);
    }

    private TextView label(String value, int sp, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(sp);
        view.setTextColor(color);
        if (bold) view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        view.setGravity(Gravity.CENTER_VERTICAL);
        return view;
    }

    private GradientDrawable round(int color, int dpRadius) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(dp(dpRadius));
        return drawable;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
