package dev.biom.swisskey;

import android.content.ContentResolver;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.io.InputStream;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.WeakHashMap;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public final class KeypadHook implements IXposedHookLoadPackage {
    private static final Uri BASE = Uri.parse("content://" + ThemeProvider.AUTHORITY);
    private static final WeakHashMap<View, Boolean> STYLED = new WeakHashMap<>();
    private static final WeakHashMap<View, Boolean> OPLUS_ROOTS = new WeakHashMap<>();
    private static final WeakHashMap<View, Boolean> OPLUS_REPORTED = new WeakHashMap<>();
    private static final WeakHashMap<View, Boolean> OPLUS_DESCRIBED = new WeakHashMap<>();
    private static Bitmap[] images;
    private static boolean activeChecked;
    private static boolean active;
    private static boolean moduleReported;
    private static final Set<String> SEEN = new HashSet<>();

    @Override public void handleLoadPackage(XC_LoadPackage.LoadPackageParam param) {
        if (!"com.android.systemui".equals(param.packageName)) return;
        String maker = Build.MANUFACTURER.toLowerCase(Locale.ROOT);
        if (!(maker.contains("oneplus") || maker.contains("oppo") || maker.contains("realme"))) return;
        try {
            // View attachment covers both AOSP NumPadKey and COUI's canvas keyboard
            // without requiring an OEM class name at module load time.
            XposedHelpers.findAndHookMethod(View.class, "onAttachedToWindow", new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam method) {
                    View view = (View) method.thisObject;
                    inspect(view);
                }
            });
            // Some OPlus views wrap their attach lifecycle. Observing insertion as well
            // also covers keyboards inflated dynamically after SystemUI startup.
            XposedHelpers.findAndHookMethod(ViewGroup.class, "addView", View.class, int.class,
                    ViewGroup.LayoutParams.class, new XC_MethodHook() {
                        @Override protected void afterHookedMethod(MethodHookParam method) {
                            View child = (View) method.args[0];
                            String n = child.getClass().getSimpleName().toLowerCase(Locale.ROOT);
                            if (n.contains("keyboard") || n.contains("numpad") || n.contains("pin")) {
                                child.post(() -> inspect(child));
                            }
                        }
                    });
            XposedBridge.log("[SwissKey] SystemUI keypad observer attached on " + Build.MANUFACTURER);
        } catch (Throwable error) {
            XposedBridge.log("[SwissKey] Could not attach keypad observer: " + error);
        }
    }

    private static void inspect(View view) {
        try {
            if (!moduleReported) {
                moduleReported = true;
                send(view, "candidate", "LSPosed: SystemUI загружен");
            }
            String name = view.getClass().getSimpleName();
            String lower = name.toLowerCase(Locale.ROOT);
            if (lower.contains("keyboard") || lower.contains("numpad") || lower.contains("pin")) {
                String value = view.getClass().getName();
                synchronized (SEEN) {
                    if (SEEN.size() < 60 && SEEN.add(value)) send(view, "candidate", value);
                }
            }
            if ("com.oplus.keyguard.security.view.OplusKeyguardFixedPinView"
                    .equals(view.getClass().getName())) {
                observeOplusPin(view);
                return;
            }
            if (!lower.contains("numerickeyboard") && !lower.contains("numpadkey") &&
                    !lower.contains("pinpadkey")) return;
            style(view, name);
        } catch (Throwable error) {
            XposedBridge.log("[SwissKey] Keypad skipped: " + error);
            send(view, "error", error.toString());
        }
    }

    private static void observeOplusPin(View root) {
        if (OPLUS_ROOTS.put(root, true) != null) return;
        root.post(() -> scanOplusPin(root));
        root.addOnLayoutChangeListener((v, l, t, r, b, oldL, oldT, oldR, oldB) -> {
            if (r - l > 0 && b - t > 0) v.post(() -> scanOplusPin(v));
        });
    }

    private static void scanOplusPin(View root) {
        try {
            if (!(root instanceof ViewGroup) || !root.isAttachedToWindow() || !isEnabled(root)) return;
            int count = styleDigits((ViewGroup) root, 0);
            if (count > 0) {
                if (OPLUS_REPORTED.put(root, true) == null)
                    send(root, "report", root.getClass().getName() + " (кнопок: " + count + ")");
            } else if (OPLUS_DESCRIBED.put(root, true) == null) {
                send(root, "structure", describeTree(root, 0, new StringBuilder()).toString());
            }
        } catch (Throwable error) {
            send(root, "error", "Oplus PIN: " + error);
            XposedBridge.log("[SwissKey] Oplus PIN scan failed: " + error);
        }
    }

    private static int styleDigits(ViewGroup group, int depth) {
        if (depth > 12) return 0;
        int found = 0;
        for (int i = 0; i < group.getChildCount(); i++) {
            View child = group.getChildAt(i);
            if (child instanceof TextView && child.getWidth() > 0 && child.getHeight() > 0) {
                int digit = textDigit((TextView) child);
                if (digit >= 0) {
                    View cell = selectCell(group, child);
                    if (!STYLED.containsKey(cell)) {
                        if (images == null) images = readTheme(rootResolver(group));
                        if (images == null) {
                            send(group, "error", "Не удалось прочитать PNG темы");
                            return found;
                        }
                        attach(cell, new KeyArtwork(images[digit]));
                        if (cell == child) ((TextView) child).setTextColor(android.graphics.Color.TRANSPARENT);
                        else ((TextView) child).setAlpha(0f);
                        STYLED.put(cell, true);
                    }
                    found++;
                }
            }
            if (child instanceof ViewGroup) found += styleDigits((ViewGroup) child, depth + 1);
        }
        return found;
    }

    private static ContentResolver rootResolver(View view) { return view.getContext().getContentResolver(); }

    private static int textDigit(TextView textView) {
        String value = textView.getText().toString().trim();
        if (value.length() == 1 && value.charAt(0) >= '0' && value.charAt(0) <= '9')
            return value.charAt(0) - '0';
        return -1;
    }

    private static View selectCell(ViewGroup parent, View digit) {
        // A full key wrapper keeps the artwork centered on the touch area.
        // If it also holds other digit labels, use the label itself.
        int dp = Math.round(180 * digit.getResources().getDisplayMetrics().density);
        if (parent.getWidth() > 0 && parent.getHeight() > 0 && parent.getWidth() <= dp &&
                parent.getHeight() <= dp && numberOfDigits(parent) == 1) return parent;
        return digit;
    }

    private static int numberOfDigits(View view) {
        if (view instanceof TextView) return textDigit((TextView) view) >= 0 ? 1 : 0;
        if (!(view instanceof ViewGroup)) return 0;
        int count = 0;
        ViewGroup group = (ViewGroup) view;
        for (int i = 0; i < group.getChildCount(); i++) count += numberOfDigits(group.getChildAt(i));
        return count;
    }

    private static StringBuilder describeTree(View view, int depth, StringBuilder output) {
        if (depth > 7 || output.length() > 3000) return output;
        output.append('\n');
        for (int j = 0; j < depth; j++) output.append(' ');
        output.append(view.getClass().getName()).append(' ')
                .append(view.getWidth()).append('x').append(view.getHeight());
        if (view instanceof ViewGroup) {
            ViewGroup group = (ViewGroup) view;
            output.append(" children=").append(group.getChildCount());
            for (int i = 0; i < group.getChildCount(); i++)
                describeTree(group.getChildAt(i), depth + 1, output);
        }
        return output;
    }

    private static boolean isEnabled(View view) {
        if (!activeChecked) {
            activeChecked = true;
            try {
                Bundle status = view.getContext().getContentResolver().call(BASE, "status", null, null);
                active = status != null && status.getBoolean("enabled", false);
            } catch (Throwable error) {
                send(view, "error", "Theme provider: " + error.getClass().getSimpleName());
            }
        }
        return active;
    }

    private static void send(View view, String method, String value) {
        try { view.getContext().getContentResolver().call(BASE, method, value, null); }
        catch (Throwable ignored) { XposedBridge.log("[SwissKey] Cannot send " + method); }
    }

    private static void style(View view, String name) {
        if (STYLED.containsKey(view)) return;
        if (!isEnabled(view)) return;
        if (images == null) images = readTheme(view.getContext().getContentResolver());
        if (images == null) return;

        if (name.toLowerCase(Locale.ROOT).contains("numerickeyboard")) {
            attach(view, new PadArtwork(images));
            XposedBridge.log("[SwissKey] Styled COUI numeric keyboard: " + view.getClass().getName());
        } else {
            int digit = digitFor(view);
            if (digit < 0) return;
            attach(view, new KeyArtwork(images[digit]));
            hideBuiltInLabels(view);
            XposedBridge.log("[SwissKey] Styled digit " + digit + " on " + view.getClass().getName());
        }
        STYLED.put(view, true);
        send(view, "report", view.getClass().getName());
    }

    private static Bitmap[] readTheme(ContentResolver resolver) {
        Bitmap[] result = new Bitmap[10];
        try {
            for (int i = 0; i < result.length; i++) {
                try (InputStream input = resolver.openInputStream(BASE.buildUpon().appendPath("digit")
                        .appendPath(Integer.toString(i)).build())) {
                    if (input == null) throw new IllegalStateException("Missing digit " + i);
                    result[i] = BitmapFactory.decodeStream(input);
                    if (result[i] == null) throw new IllegalStateException("Invalid image " + i);
                }
            }
            return result;
        } catch (Throwable error) {
            XposedBridge.log("[SwissKey] Could not load theme: " + error);
            for (Bitmap image : result) if (image != null) image.recycle();
            return null;
        }
    }

    private static int digitFor(View view) {
        try {
            int digit = XposedHelpers.getIntField(view, "mDigit");
            if (digit >= 0 && digit <= 9) return digit;
        } catch (Throwable ignored) { /* OEMs may remove the AOSP field. */ }
        CharSequence description = view.getContentDescription();
        if (description != null && description.length() == 1 && description.charAt(0) >= '0'
                && description.charAt(0) <= '9') return description.charAt(0) - '0';
        return -1;
    }

    private static void hideBuiltInLabels(View view) {
        if (!(view instanceof ViewGroup)) return;
        ViewGroup group = (ViewGroup) view;
        for (int i = 0; i < group.getChildCount(); i++) {
            View child = group.getChildAt(i);
            if (child instanceof TextView) ((TextView) child).setAlpha(0f);
        }
    }

    private static void attach(View view, android.graphics.drawable.Drawable drawable) {
        drawable.setBounds(0, 0, view.getWidth(), view.getHeight());
        view.getOverlay().add(drawable); // The native keypad retains all input and accessibility.
        view.addOnLayoutChangeListener((v, left, top, right, bottom, oldLeft, oldTop, oldRight, oldBottom) -> {
            drawable.setBounds(0, 0, right - left, bottom - top);
            drawable.invalidateSelf();
            v.invalidate();
        });
    }

    private static final class KeyArtwork extends android.graphics.drawable.Drawable {
        private final Bitmap bitmap;
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        KeyArtwork(Bitmap bitmap) { this.bitmap = bitmap; }
        @Override public void draw(Canvas canvas) {
            Rect b = getBounds();
            canvas.drawBitmap(bitmap, null, new Rect(b), paint);
        }
        @Override public void setAlpha(int alpha) { paint.setAlpha(alpha); invalidateSelf(); }
        @Override public void setColorFilter(android.graphics.ColorFilter filter) { paint.setColorFilter(filter); invalidateSelf(); }
        @Override public int getOpacity() { return android.graphics.PixelFormat.TRANSLUCENT; }
    }

    private static final class PadArtwork extends android.graphics.drawable.Drawable {
        private final Bitmap[] bitmaps;
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        private final int[] digits = {1,2,3,4,5,6,7,8,9,-1,0,-1};
        PadArtwork(Bitmap[] bitmaps) { this.bitmaps = bitmaps; }
        @Override public void draw(Canvas canvas) {
            Rect b = getBounds();
            if (b.width() <= 0 || b.height() <= 0) return;
            float cell = Math.min(b.width() * 68f / 248f, b.height() * 68f / 326f);
            float stepX = (b.width() - cell) / 2f;
            float stepY = (b.height() - cell) / 3f;
            // Original .passthm artwork has transparent margins; scale the visible circle
            // to the native 68dp cell without changing the keypad's touch targets.
            float artworkW = cell * 1.48f;
            float artworkH = artworkW * 287f / 305f;
            for (int index = 0; index < digits.length; index++) {
                int digit = digits[index];
                if (digit < 0) continue;
                float x = b.left + cell / 2f + (index % 3) * stepX;
                float y = b.top + cell / 2f + (index / 3) * stepY;
                canvas.drawBitmap(bitmaps[digit], null,
                        new android.graphics.RectF(x - artworkW/2, y - artworkH/2,
                                x + artworkW/2, y + artworkH/2), paint);
            }
        }
        @Override public void setAlpha(int alpha) { paint.setAlpha(alpha); invalidateSelf(); }
        @Override public void setColorFilter(android.graphics.ColorFilter filter) { paint.setColorFilter(filter); invalidateSelf(); }
        @Override public int getOpacity() { return android.graphics.PixelFormat.TRANSLUCENT; }
    }
}
