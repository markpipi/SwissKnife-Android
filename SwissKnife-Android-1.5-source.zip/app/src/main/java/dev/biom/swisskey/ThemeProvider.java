package dev.biom.swisskey;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Binder;
import android.os.ParcelFileDescriptor;

import java.io.File;
import java.io.FileNotFoundException;

public final class ThemeProvider extends ContentProvider {
    public static final String AUTHORITY = "dev.biom.swisskey.theme";

    @Override public boolean onCreate() { return true; }
    @Override public Bundle call(String method, String arg, Bundle extras) {
        if ("report".equals(method) || "candidate".equals(method) ||
                "error".equals(method) || "structure".equals(method)) {
            String[] packages = getContext().getPackageManager().getPackagesForUid(Binder.getCallingUid());
            if (packages != null) for (String name : packages) {
                if ("com.android.systemui".equals(name)) {
                    android.content.SharedPreferences prefs = ThemeStore.storage(getContext()).getSharedPreferences("theme", 0);
                    android.content.SharedPreferences.Editor edit = prefs.edit();
                    if ("report".equals(method)) edit.putString("last_keypad", arg).remove("last_error");
                    if ("error".equals(method)) edit.putString("last_error", arg);
                    if ("structure".equals(method)) edit.putString("structure",
                            arg == null ? "" : arg.substring(0, Math.min(arg.length(), 3500)));
                    if ("candidate".equals(method)) {
                        String previous = prefs.getString("candidates", "");
                        if (previous.length() < 4000 && !previous.contains("\n" + arg + "\n")) {
                            edit.putString("candidates", previous + "\n" + arg + "\n");
                        }
                    }
                    edit.apply();
                    break;
                }
            }
            return Bundle.EMPTY;
        }
        if (!"status".equals(method)) return null;
        Bundle result = new Bundle();
        result.putBoolean("enabled", ThemeStore.enabled(getContext()));
        result.putString("last_keypad", ThemeStore.storage(getContext()).getSharedPreferences("theme", 0)
                .getString("last_keypad", ""));
        result.putString("last_error", ThemeStore.storage(getContext()).getSharedPreferences("theme", 0)
                .getString("last_error", ""));
        return result;
    }
    @Override public ParcelFileDescriptor openFile(Uri uri, String mode) throws FileNotFoundException {
        if (!"r".equals(mode) || uri.getPathSegments().size() != 2 ||
                !"digit".equals(uri.getPathSegments().get(0))) throw new FileNotFoundException("Invalid path");
        String number = uri.getPathSegments().get(1);
        if (!number.matches("[0-9]")) throw new FileNotFoundException("Invalid digit");
        File file = ThemeStore.image(getContext(), number.charAt(0) - '0');
        return ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY);
    }
    @Override public String getType(Uri uri) { return "image/png"; }
    @Override public Cursor query(Uri uri, String[] projection, String selection, String[] args, String sort) { return null; }
    @Override public Uri insert(Uri uri, ContentValues values) { throw new UnsupportedOperationException(); }
    @Override public int delete(Uri uri, String selection, String[] args) { throw new UnsupportedOperationException(); }
    @Override public int update(Uri uri, ContentValues values, String selection, String[] args) { throw new UnsupportedOperationException(); }
}
