package dev.biom.swisskey;

import android.content.Context;
import android.graphics.BitmapFactory;
import android.net.Uri;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Enumeration;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipException;
import java.util.zip.ZipFile;

final class ThemeStore {
    private ThemeStore() {}
    private static final Pattern LANGUAGE_DIGIT = Pattern.compile("^[a-z]{2}[-_]([0-9])(?:[-_].*)?\\.png$",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern PLAIN_DIGIT = Pattern.compile("^(?:digit[-_]?|key[-_]?|number[-_]?)?([0-9])(?:[-_].*)?\\.png$",
            Pattern.CASE_INSENSITIVE);

    static Context storage(Context context) { return context.createDeviceProtectedStorageContext(); }
    static File directory(Context context) { return new File(storage(context).getFilesDir(), "keypad"); }
    static File image(Context context, int digit) { return new File(directory(context), digit + ".png"); }
    static boolean enabled(Context context) {
        return storage(context).getSharedPreferences("theme", 0).getBoolean("enabled", false);
    }
    static void setEnabled(Context context, boolean value) {
        storage(context).getSharedPreferences("theme", 0).edit().putBoolean("enabled", value)
                .remove("last_keypad").remove("last_error").remove("candidates")
                .remove("structure").apply();
    }

    static void ensureDefault(Context context) throws IOException {
        if (complete(directory(context))) return;
        File staging = new File(storage(context).getFilesDir(), "keypad-default-staging");
        delete(staging);
        if (!staging.mkdirs()) throw new IOException("Не удалось создать каталог темы");
        try {
            for (int i = 0; i < 10; i++) {
                try (InputStream in = context.getAssets().open("default_theme/" + i + ".png")) {
                    writeImage(in, new File(staging, i + ".png"));
                }
            }
            install(context, staging);
        } finally { delete(staging); }
    }

    static void importTheme(Context context, Uri uri) throws IOException {
        File archive = new File(context.getCacheDir(), "incoming.passthm");
        File staging = new File(storage(context).getFilesDir(), "keypad-import-staging");
        delete(staging);
        if (!staging.mkdirs()) throw new IOException("Не удалось создать каталог темы");
        try {
            try (InputStream in = context.getContentResolver().openInputStream(uri);
                 FileOutputStream out = new FileOutputStream(archive)) {
                if (in == null) throw new IOException("Выбранный файл недоступен");
                copyLimited(in, out, 50_000_000);
            } catch (SecurityException e) {
                throw new IOException("Нет доступа к выбранному файлу. Выбери его через системный проводник.", e);
            }
            try (ZipFile zip = new ZipFile(archive)) {
                Enumeration<? extends ZipEntry> entries = zip.entries();
                ZipEntry[] selected = new ZipEntry[10];
                int[] best = new int[10];
                int count = 0;
                while (entries.hasMoreElements()) {
                    ZipEntry entry = entries.nextElement();
                    if (++count > 1000) throw new IOException("В архиве слишком много файлов");
                    if (entry.isDirectory()) continue;
                    String name = entry.getName();
                    String basename = name.substring(name.lastIndexOf('/') + 1);
                    int digit = digitFromName(basename);
                    if (digit < 0) continue;
                    int score = score(name, basename);
                    if (selected[digit] == null || score > best[digit]) {
                        selected[digit] = entry;
                        best[digit] = score;
                    }
                }
                StringBuilder missing = new StringBuilder();
                for (int digit = 0; digit < 10; digit++) {
                    if (selected[digit] == null) {
                        if (missing.length() != 0) missing.append(", ");
                        missing.append(digit);
                    }
                }
                if (missing.length() != 0)
                    throw new IOException("Не найдены PNG для цифр: " + missing + ". Нужен архив .passthm с 0–9.");
                for (int digit = 0; digit < 10; digit++) {
                    if (selected[digit].getSize() > 2_000_000)
                        throw new IOException("Слишком большое изображение " + digit);
                    try (InputStream in = zip.getInputStream(selected[digit])) {
                        writeImage(in, new File(staging, digit + ".png"));
                    }
                }
            } catch (ZipException e) {
                throw new IOException("Файл не является исправным архивом .passthm или ZIP", e);
            }
            install(context, staging);
        } finally {
            delete(staging);
            if (archive.exists()) archive.delete();
        }
    }

    private static int digitFromName(String basename) {
        Matcher language = LANGUAGE_DIGIT.matcher(basename);
        if (language.matches()) return language.group(1).charAt(0) - '0';
        Matcher plain = PLAIN_DIGIT.matcher(basename);
        return plain.matches() ? plain.group(1).charAt(0) - '0' : -1;
    }

    private static int score(String path, String basename) {
        String value = path.toLowerCase(Locale.ROOT);
        String name = basename.toLowerCase(Locale.ROOT);
        int result = name.startsWith("en-") || name.startsWith("en_") ? 100 : 0;
        if (value.contains("telephonyui-10")) result += 30;
        if (name.contains("white")) result += 10;
        if (name.contains("bold")) result += 5;
        return result;
    }

    private static void writeImage(InputStream in, File dest) throws IOException {
        try (FileOutputStream out = new FileOutputStream(dest)) { copyLimited(in, out, 2_000_000); }
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(dest.getAbsolutePath(), options);
        if (!"image/png".equals(options.outMimeType) || options.outWidth < 16 || options.outHeight < 16 ||
                options.outWidth > 2048 || options.outHeight > 2048) {
            throw new IOException("Неверный PNG: " + dest.getName());
        }
    }

    private static void copyLimited(InputStream in, FileOutputStream out, int limit) throws IOException {
        byte[] buffer = new byte[8192];
        int size = 0, n;
        while ((n = in.read(buffer)) != -1) {
            size += n;
            if (size > limit) throw new IOException("Превышен размер файла");
            out.write(buffer, 0, n);
        }
        out.getFD().sync();
    }

    private static boolean complete(File dir) {
        for (int i = 0; i < 10; i++) if (!new File(dir, i + ".png").isFile()) return false;
        return true;
    }

    private static void install(Context context, File staging) throws IOException {
        File active = directory(context);
        File backup = new File(storage(context).getFilesDir(), "keypad-backup");
        delete(backup);
        if (active.exists() && !active.renameTo(backup)) throw new IOException("Не удалось сохранить старую тему");
        if (!staging.renameTo(active)) {
            if (backup.exists()) backup.renameTo(active);
            throw new IOException("Не удалось применить тему");
        }
        delete(backup);
    }

    private static void delete(File path) {
        if (path.isDirectory()) {
            File[] children = path.listFiles();
            if (children != null) for (File child : children) delete(child);
        }
        if (path.exists()) path.delete();
    }
}
