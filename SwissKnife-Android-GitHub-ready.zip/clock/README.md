# Swiss Clock 1.0

Standalone Android app and LSPosed module for styling the live lock-screen clock on ColorOS 17. Package: `dev.biom.swissclock`. It is independent of Swiss Knife PIN (`dev.biom.swisskey`).

Install the APK, enable **Swiss Clock** for `com.android.systemui` in LSPosed, open the app, pick a font, color, size and position, then tap **Применить часы**. Grant root for the SystemUI restart. **Вернуть системные часы** disables this module and restarts SystemUI. The original PIN app may stay installed and enabled separately.

The hook finds clock TextViews inside the keyguard hierarchy. Its time text is supplied by the system. On this device the exact clock class has not been observed yet; if the clock stays unchanged, open the lock screen, return to the app and copy its diagnostics to identify the class. Always On Display is not modified.

The signed APK was compiled offline using Android SDK Platform 35 and Build Tools 35.0.0, target SDK 36, JDK 21. To rebuild from the parent directory set `ANDROID_HOME` and `JAVA_HOME`, then run `./build-clock.sh`. The source archive includes the build script and this version's debug signing key for future in-place updates. It creates temporary compile-only Xposed API stubs and excludes them from the APK.
