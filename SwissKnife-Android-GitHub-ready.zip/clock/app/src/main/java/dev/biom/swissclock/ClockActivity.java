package dev.biom.swissclock;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.OpenableColumns;
import android.text.format.DateFormat;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public final class ClockActivity extends Activity {
    private static final int PICK=101, BG=0xff090d16, CARD=0xff151d2c;
    private static final int WHITE=0xfff4f7ff, MUTED=0xff9caac1, CYAN=0xff89e8ff;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final Runnable tick=new Runnable(){public void run(){updateTime();handler.postDelayed(this,15000);}};
    private LinearLayout body;
    private TextView clockFace,clockDate,sizeLabel;
    private String notice;

    @Override public void onCreate(Bundle state){super.onCreate(state);getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        render();}
    private SharedPreferences prefs(){return ClockSettings.prefs(this);}
    private int size(){return prefs().getInt("size",76);}
    private int color(){return prefs().getInt("color",Color.WHITE);}
    private int font(){return prefs().getInt("font",0);}
    private int position(){return prefs().getInt("position",0);}

    private void render(){
        LinearLayout shell=new LinearLayout(this);shell.setOrientation(1);shell.setBackgroundColor(BG);
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setVerticalScrollBarEnabled(false);
        body=new LinearLayout(this);body.setOrientation(1);body.setPadding(dp(20),dp(22),dp(20),dp(30));
        scroll.addView(body);shell.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout brand=line();brand.setGravity(Gravity.CENTER_VERTICAL);
        ImageView logo=new ImageView(this);logo.setImageResource(R.drawable.swissknife_mark);
        brand.addView(logo,new LinearLayout.LayoutParams(dp(32),dp(32)));
        TextView name=label("SWISS CLOCK",13,CYAN,true);name.setLetterSpacing(.18f);
        LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(-2,-2);np.leftMargin=dp(10);brand.addView(name,np);
        body.addView(brand);
        TextView title=label("Часы",36,WHITE,true);
        LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(-1,-2);tp.topMargin=dp(24);body.addView(title,tp);
        body.addView(label("Свой стиль экрана блокировки",15,MUTED,false));
        clockFace=null;clockDate=null;
        clockPage();
        setContentView(shell);updateTime();
    }

    private void clockPage(){
        section("ЖИВОЙ ПРЕДПРОСМОТР");
        FrameLayout preview=new FrameLayout(this);
        preview.setBackground(gradient(new int[]{0xff364d70,0xff242e4c,0xff11182b},26));
        preview.setClipToOutline(true);body.addView(preview,new LinearLayout.LayoutParams(-1,dp(345)));
        TextView badge=label("●  LOCK SCREEN",11,0xffcad5e9,true);badge.setLetterSpacing(.13f);
        FrameLayout.LayoutParams bp=new FrameLayout.LayoutParams(-2,-2,Gravity.TOP|Gravity.START);
        bp.leftMargin=dp(22);bp.topMargin=dp(22);preview.addView(badge,bp);
        LinearLayout clock=new LinearLayout(this);clock.setOrientation(1);clock.setGravity(Gravity.CENTER);
        preview.addView(clock,new FrameLayout.LayoutParams(-1,dp(205),Gravity.CENTER));
        clockFace=label("",76,WHITE,false);clockFace.setGravity(Gravity.CENTER);clockFace.setIncludeFontPadding(false);
        clock.addView(clockFace,new LinearLayout.LayoutParams(-1,-2));
        clockDate=label("",15,0xffdce5f2,false);clockDate.setGravity(Gravity.CENTER);
        clock.addView(clockDate,new LinearLayout.LayoutParams(-1,-2));
        TextView hint=label("Проведите вверх для разблокировки  ↑",12,0xffbac8db,false);
        hint.setGravity(Gravity.CENTER);preview.addView(hint,new FrameLayout.LayoutParams(-1,dp(45),Gravity.BOTTOM));
        section("ШРИФТ");
        LinearLayout fonts=line();String[] names={"Тонкий","Плотный","Моно"};
        for(int i=0;i<3;i++){final int chosen=i;TextView item=pill(names[i],font()==i);
            LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(49),1);if(i!=0)p.leftMargin=dp(8);
            fonts.addView(item,p);item.setOnClickListener(v->{prefs().edit().putInt("font",chosen).apply();rerender();});}
        body.addView(fonts);
        section("ЦВЕТ");
        LinearLayout colors=line();
        for(int c:ClockSettings.COLORS){FrameLayout cell=new FrameLayout(this);
            colors.addView(cell,new LinearLayout.LayoutParams(0,dp(55),1));
            View dot=new View(this);GradientDrawable shape=round(c,50);dot.setBackground(shape);
            cell.addView(dot,new FrameLayout.LayoutParams(dp(37),dp(37),Gravity.CENTER));
            if(c==color()){View ring=new View(this);GradientDrawable r=round(Color.TRANSPARENT,50);
                r.setStroke(dp(2),c);ring.setBackground(r);
                cell.addView(ring,new FrameLayout.LayoutParams(dp(48),dp(48),Gravity.CENTER));}
            cell.setOnClickListener(v->{prefs().edit().putInt("color",c).apply();rerender();});}
        body.addView(colors);
        section("РАЗМЕР ЦИФР");
        LinearLayout sliderCard=card();LinearLayout row=line();
        row.addView(label("Размер",16,WHITE,true),new LinearLayout.LayoutParams(0,dp(40),1));
        sizeLabel=label(size()+" sp",14,CYAN,true);row.addView(sizeLabel);sliderCard.addView(row);
        SeekBar slider=new SeekBar(this);slider.setMax(48);slider.setProgress(Math.max(0,Math.min(48,size()-48)));
        slider.setProgressTintList(android.content.res.ColorStateList.valueOf(CYAN));
        slider.setThumbTintList(android.content.res.ColorStateList.valueOf(CYAN));
        sliderCard.addView(slider,new LinearLayout.LayoutParams(-1,dp(44)));
        slider.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            public void onProgressChanged(SeekBar s,int value,boolean user){if(!user)return;
                prefs().edit().putInt("size",48+value).apply();sizeLabel.setText((48+value)+" sp");updateTime();}
            public void onStartTrackingTouch(SeekBar s){}public void onStopTrackingTouch(SeekBar s){} });
        section("ПОЛОЖЕНИЕ");
        LinearLayout positions=line();int[] offsets={-60,0,60};String[] labels={"Выше","По центру","Ниже"};
        for(int i=0;i<3;i++){int chosen=offsets[i];TextView item=pill(labels[i],position()==chosen);
            LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(49),1);if(i!=0)p.leftMargin=dp(8);
            positions.addView(item,p);item.setOnClickListener(v->{prefs().edit().putInt("position",chosen).apply();rerender();});}
        body.addView(positions);
        action("Применить часы",true,()->{ClockSettings.enabled(this,true);restartSystemUi();});
        action("Вернуть системные часы",false,()->{ClockSettings.enabled(this,false);restartSystemUi();});
        section("СОСТОЯНИЕ");LinearLayout status=card();
        status.addView(label(prefs().getBoolean("enabled",false)?"●  Часы включены":"○  Часы выключены",16,CYAN,true));
        String reported=prefs().getString("last_clock","");String error=prefs().getString("clock_error","");
        caption(status,!error.isEmpty()?"Ошибка: "+error:reported.isEmpty()?"После применения открой экран блокировки.":"Компонент: "+reported);
        if(notice!=null)caption(status,notice);
        TextView diagnostic=label("Скопировать диагностику  ↗",13,CYAN,true);
        status.addView(diagnostic,new LinearLayout.LayoutParams(-1,dp(45)));
        diagnostic.setOnClickListener(v->copy("Часы: "+prefs().getString("last_clock","")+"\nОшибка: "+prefs().getString("clock_error","")+"\nКомпоненты: "+prefs().getString("clock_candidates","")));
    }
    private void updateTime(){if(clockFace==null)return;
        clockFace.setText(new SimpleDateFormat(DateFormat.is24HourFormat(this)?"HH:mm":"h:mm",Locale.getDefault()).format(new Date()));
        clockDate.setText(new SimpleDateFormat("EEEE, d MMMM",new Locale("ru")).format(new Date()));
        clockFace.setTextSize(TypedValue.COMPLEX_UNIT_SP,size());clockFace.setTextColor(color());
        clockFace.setTypeface(Typeface.create(font()==0?"sans-serif-light":font()==1?"sans-serif":"monospace",font()==1?Typeface.BOLD:Typeface.NORMAL));
        clockFace.setTranslationY(dp(position()));clockDate.setTranslationY(dp(position()));}

    private void section(String value){TextView title=label(value,12,MUTED,true);title.setLetterSpacing(.12f);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=dp(27);p.bottomMargin=dp(11);body.addView(title,p);}
    private LinearLayout card(){LinearLayout panel=new LinearLayout(this);panel.setOrientation(1);panel.setPadding(dp(18),dp(16),dp(18),dp(15));
        panel.setBackground(round(CARD,20));body.addView(panel,new LinearLayout.LayoutParams(-1,-2));return panel;}
    private void caption(LinearLayout panel,String value){TextView text=label(value,13,MUTED,false);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=dp(9);p.bottomMargin=dp(5);panel.addView(text,p);}
    private void action(String value,boolean primary,Runnable click){TextView button=label(value+"   →",16,primary?BG:WHITE,true);
        button.setGravity(Gravity.CENTER);button.setBackground(round(primary?CYAN:0xff1c2739,17));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(57));p.topMargin=dp(primary?24:11);body.addView(button,p);button.setOnClickListener(v->click.run());}
    private TextView pill(String value,boolean active){TextView t=label(value,14,active?BG:MUTED,active);
        t.setGravity(Gravity.CENTER);t.setBackground(round(active?CYAN:CARD,14));return t;}
    private TextView label(String value,int sp,int color,boolean bold){TextView t=new TextView(this);t.setText(value);t.setTextColor(color);
        t.setTextSize(sp);t.setGravity(Gravity.CENTER_VERTICAL);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private LinearLayout line(){LinearLayout l=new LinearLayout(this);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private GradientDrawable round(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
    private GradientDrawable gradient(int[] colors,int radius){GradientDrawable d=new GradientDrawable(GradientDrawable.Orientation.TL_BR,colors);d.setCornerRadius(dp(radius));return d;}
    private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
    private void rerender(){ScrollView old=(ScrollView)body.getParent();int y=old.getScrollY();render();ScrollView current=(ScrollView)body.getParent();current.post(()->current.scrollTo(0,y));}
    private void copy(String value){((ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("Swiss Clock",value));Toast.makeText(this,"Диагностика скопирована",Toast.LENGTH_SHORT).show();}
    private void restartSystemUi(){notice="Перезапускаю SystemUI…";render();new Thread(()->{
        String result;try{Process p=new ProcessBuilder("su","-c","killall com.android.systemui").start();
            result=p.waitFor()==0?"SystemUI перезапущен. Проверь экран блокировки.":"Root не перезапустил SystemUI. Перезагрузи телефон.";
        }catch(Exception e){result="Не удалось перезапустить SystemUI. Перезагрузи телефон.";}
        String msg=result;runOnUiThread(()->{notice=msg;render();Toast.makeText(this,msg,Toast.LENGTH_LONG).show();});
    },"systemui-restart").start();}
    @Override protected void onResume(){super.onResume();handler.removeCallbacks(tick);handler.post(tick);}
    @Override protected void onPause(){handler.removeCallbacks(tick);super.onPause();}
}
