package dev.biom.swissclock;
import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.os.Binder;
import android.os.Bundle;
public final class ClockProvider extends ContentProvider {
 public static final String AUTHORITY="dev.biom.swissclock.settings";
 @Override public boolean onCreate(){return true;}
 @Override public Bundle call(String method,String arg,Bundle extras){
  if("clock_status".equals(method))return ClockSettings.status(getContext());
  if(!"clock_report".equals(method)&&!"clock_candidate".equals(method)&&!"clock_error".equals(method))return null;
  String[] packages=getContext().getPackageManager().getPackagesForUid(Binder.getCallingUid());
  if(packages!=null)for(String name:packages)if("com.android.systemui".equals(name)){
   android.content.SharedPreferences p=ClockSettings.prefs(getContext());
   android.content.SharedPreferences.Editor edit=p.edit();
   if("clock_report".equals(method))edit.putString("last_clock",arg).remove("clock_error");
   if("clock_error".equals(method))edit.putString("clock_error",arg);
   if("clock_candidate".equals(method)){
    String prev=p.getString("clock_candidates","");
    if(prev.length()<3000&&!prev.contains("\n"+arg+"\n"))edit.putString("clock_candidates",prev+"\n"+arg+"\n");
   }
   edit.apply();break;
  }
  return Bundle.EMPTY;
 }
 @Override public String getType(Uri uri){return null;}
 @Override public Cursor query(Uri uri,String[] projection,String selection,String[] args,String sortOrder){return null;}
 @Override public Uri insert(Uri uri,ContentValues values){throw new UnsupportedOperationException();}
 @Override public int delete(Uri uri,String selection,String[] args){throw new UnsupportedOperationException();}
 @Override public int update(Uri uri,ContentValues values,String selection,String[] args){throw new UnsupportedOperationException();}
}
