package dev.biom.swissclock;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewParent;
import android.view.ViewGroup;
import android.widget.TextView;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.WeakHashMap;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;
public final class ClockHook implements IXposedHookLoadPackage {
 private static final Uri PROVIDER=Uri.parse("content://"+ClockProvider.AUTHORITY);
 private static final WeakHashMap<View,Boolean> STYLED=new WeakHashMap<>();
 private static final Set<String> SEEN=new HashSet<>();
 private static Bundle settings;
 @Override public void handleLoadPackage(XC_LoadPackage.LoadPackageParam param) {
  if (!"com.android.systemui".equals(param.packageName)) return;
  try {
   XposedHelpers.findAndHookMethod(View.class,"onAttachedToWindow",new XC_MethodHook(){
    @Override protected void afterHookedMethod(MethodHookParam p){inspect((View)p.thisObject);}
   });
   XposedHelpers.findAndHookMethod(ViewGroup.class,"addView",View.class,int.class,
    ViewGroup.LayoutParams.class,new XC_MethodHook(){
     @Override protected void afterHookedMethod(MethodHookParam p){View child=(View)p.args[0];
      if(child.getClass().getName().toLowerCase(Locale.ROOT).contains("clock"))child.post(()->inspect(child));}
    });
   XposedBridge.log("[SwissClock] SystemUI observer attached");
  }catch(Throwable e){XposedBridge.log("[SwissClock] Observer failed: "+e);}
 }
 static void inspect(View view){try{
  String cls=view.getClass().getName(),name=cls.toLowerCase(Locale.ROOT);
  if(!(view instanceof TextView)&&!name.contains("clock"))return;
  String id=id(view),parents=parents(view);
  if(!keyguard(name)&&!keyguard(id)&&!keyguard(parents))return;
  if(excluded(name)||excluded(id)||excluded(parents))return;
  if(name.contains("clock")&&SEEN.size()<40&&SEEN.add(cls))report(view,"clock_candidate",cls+" #"+id);
  if(!(view instanceof TextView)||STYLED.containsKey(view))return;
  TextView clock=(TextView)view;
  String current=clock.getText().toString().trim();
  boolean time=current.matches("[0-9０-９]{1,2}[:：.][0-9０-９]{2}(?:\\s*[AaPp][Mm])?");
  boolean named=(name.contains("clock")||id.contains("clock")||id.contains("time"))&&!id.contains("date");
  if(!time&&!named)return;
  if(settings==null)settings=view.getContext().getContentResolver().call(PROVIDER,"clock_status",null,null);
  if(settings==null||!settings.getBoolean("enabled"))return;
  int size=settings.getInt("size",76),color=settings.getInt("color",-1),font=settings.getInt("font",0),position=settings.getInt("position",0);
  if(size<48||size>96||font<0||font>2||position< -60||position>60)throw new IllegalArgumentException("Clock preferences");
  clock.setTextColor(color);clock.setTextSize(TypedValue.COMPLEX_UNIT_SP,size);
  clock.setTypeface(Typeface.create(font==0?"sans-serif-light":font==1?"sans-serif":"monospace",font==1?Typeface.BOLD:Typeface.NORMAL));
  clock.setTranslationY(position*view.getResources().getDisplayMetrics().density);
  STYLED.put(view,true);report(view,"clock_report",cls+" #"+id);
 }catch(Throwable e){XposedBridge.log("[SwissKnife] Clock: "+e);report(view,"clock_error",e.getClass().getSimpleName()+": "+e.getMessage());}}
 private static boolean keyguard(String s){return s.contains("keyguard")||s.contains("lockscreen")||s.contains("lock_screen")||s.contains("deviceentry");}
 private static boolean excluded(String s){return s.contains("statusbar")||s.contains("status_bar")||s.contains("aod")||s.contains("doze");}
 private static String parents(View view){StringBuilder b=new StringBuilder();ViewParent p=view.getParent();for(int i=0;p instanceof View&&i<14;i++){View v=(View)p;b.append(v.getClass().getName().toLowerCase(Locale.ROOT)).append('/').append(id(v)).append(';');p=v.getParent();}return b.toString();}
 private static String id(View v){try{return v.getId()==View.NO_ID?"":v.getResources().getResourceEntryName(v.getId()).toLowerCase(Locale.ROOT);}catch(Throwable e){return "";}}
 private static void report(View v,String method,String value){try{v.getContext().getContentResolver().call(PROVIDER,method,value,null);}catch(Throwable ignored){}}
}
