package dev.biom.swissclock;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
final class ClockSettings {
 static final int[] COLORS={Color.WHITE,0xff8cecff,0xffc6adff,0xffffaba5,0xffffd59a,0xffb9e8c9};
 static SharedPreferences prefs(Context c){return c.createDeviceProtectedStorageContext().getSharedPreferences("clock",0);}
 static Bundle status(Context c){SharedPreferences p=prefs(c);Bundle b=new Bundle();b.putBoolean("enabled",p.getBoolean("enabled",false));b.putInt("size",p.getInt("size",76));b.putInt("color",p.getInt("color",Color.WHITE));b.putInt("font",p.getInt("font",0));b.putInt("position",p.getInt("position",0));return b;}
 static void enabled(Context c,boolean value){prefs(c).edit().putBoolean("enabled",value).remove("last_clock").remove("clock_error").remove("clock_candidates").apply();}
}
