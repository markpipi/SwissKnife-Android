#!/bin/bash
set -euo pipefail
work_root="$(pwd)"
sdk_root="${ANDROID_HOME:?Set ANDROID_HOME to the Android SDK directory}"
jdk_root="${JAVA_HOME:?Set JAVA_HOME to JDK 21}"
bt="$sdk_root/build-tools/35.0.0"
platform="$sdk_root/platforms/android-35/android.jar"
mkdir -p offline-clock/stubs/de/robv/android/xposed/callbacks offline-clock/classes offline-clock/gen offline-clock/res offline-clock/dex
cat > offline-clock/stubs/de/robv/android/xposed/IXposedHookLoadPackage.java <<'JAVA'
package de.robv.android.xposed;
import de.robv.android.xposed.callbacks.XC_LoadPackage;
public interface IXposedHookLoadPackage {void handleLoadPackage(XC_LoadPackage.LoadPackageParam param) throws Throwable;}
JAVA
cat > offline-clock/stubs/de/robv/android/xposed/XC_MethodHook.java <<'JAVA'
package de.robv.android.xposed;
public abstract class XC_MethodHook {
 public static class MethodHookParam {public Object thisObject;public Object[] args;}
 protected void beforeHookedMethod(MethodHookParam p) throws Throwable {}
 protected void afterHookedMethod(MethodHookParam p) throws Throwable {}
}
JAVA
cat > offline-clock/stubs/de/robv/android/xposed/XposedBridge.java <<'JAVA'
package de.robv.android.xposed;
public final class XposedBridge {public static void log(String s) {}}
JAVA
cat > offline-clock/stubs/de/robv/android/xposed/XposedHelpers.java <<'JAVA'
package de.robv.android.xposed;
public final class XposedHelpers {public static Object findAndHookMethod(Class<?> c,String n,Object... a){return null;}
 public static int getIntField(Object o,String n){return 0;}}
JAVA
cat > offline-clock/stubs/de/robv/android/xposed/callbacks/XC_LoadPackage.java <<'JAVA'
package de.robv.android.xposed.callbacks;
public final class XC_LoadPackage {public static class LoadPackageParam {public String packageName;}}
JAVA
"$jdk_root/bin/javac" -d offline-clock/classes $(find offline-clock/stubs -name '*.java')
"$jdk_root/bin/jar" cf offline-clock/xposed-api.jar -C offline-clock/classes .
sed 's/<manifest xmlns:android="http:\/\/schemas.android.com\/apk\/res\/android">/<manifest xmlns:android="http:\/\/schemas.android.com\/apk\/res\/android" package="dev.biom.swissclock">/' clock/app/src/main/AndroidManifest.xml > offline-clock/AndroidManifest.xml
"$bt/aapt2" compile --dir clock/app/src/main/res -o offline-clock/res
"$bt/aapt2" link -I "$platform" --manifest offline-clock/AndroidManifest.xml --java offline-clock/gen --min-sdk-version 29 --target-sdk-version 36 --version-code 1 --version-name 1.0 -A clock/app/src/main/assets -o offline-clock/resources.apk offline-clock/res/*.flat
"$jdk_root/bin/javac" -source 17 -target 17 -cp "$platform:offline-clock/xposed-api.jar" -d offline-clock/classes $(find offline-clock/gen clock/app/src/main/java -name '*.java')
mkdir -p offline-clock/app-classes
cp -a offline-clock/classes/dev offline-clock/app-classes/
"$bt/d8" --lib "$platform" --classpath offline-clock/xposed-api.jar --min-api 29 --output offline-clock/dex $(find offline-clock/app-classes -name '*.class')
cp offline-clock/resources.apk offline-clock/unsigned.apk
(cd offline-clock/dex && "$bt/aapt" add ../unsigned.apk classes.dex >/dev/null)
"$bt/zipalign" -f 4 offline-clock/unsigned.apk offline-clock/aligned.apk
if [ ! -f clock/signing/debug.keystore ]; then
 mkdir -p clock/signing
 "$jdk_root/bin/keytool" -genkeypair -noprompt -keystore clock/signing/debug.keystore -storepass android -keypass android -alias androiddebugkey -dname 'CN=Android Debug,O=Android,C=US' -keyalg RSA -keysize 2048 -validity 10000 >/dev/null
fi
"$bt/apksigner" sign --ks clock/signing/debug.keystore --ks-key-alias androiddebugkey --ks-pass pass:android --key-pass pass:android --out SwissClock-ColorOS17-1.0-debug.apk offline-clock/aligned.apk
"$bt/apksigner" verify --verbose SwissClock-ColorOS17-1.0-debug.apk
"$bt/aapt" dump badging SwissClock-ColorOS17-1.0-debug.apk | head -3
